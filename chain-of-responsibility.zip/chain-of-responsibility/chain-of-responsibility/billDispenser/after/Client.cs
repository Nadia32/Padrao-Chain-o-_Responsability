﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chain_of_responsibility.billDispenser.after
{
    internal class Client
    {
        /*public static void Main(string[] args)
        {
            Dispenser dispenser = new Dispenser();
            Console.WriteLine("withdrawing $326...");
            dispenser.WithDraw(326);
            Console.WriteLine("withdrawing $1589...");
            dispenser.WithDraw(1589);

            *//*Dispenser customDispenser = new Dispenser(
                new Bill(256), new Bill(128), new Bill(64),
                new Bill(32), new Bill(16), new Bill(8), new Bill(4), new Bill(2), new Bill(1));

            Console.WriteLine("Withdrawing $326...");
            customDispenser.WithDraw(326);
            Console.WriteLine("withdrawing $1589...");
            customDispenser.WithDraw(1589);
*//*
            Console.ReadKey();
        }*/
    }

}
