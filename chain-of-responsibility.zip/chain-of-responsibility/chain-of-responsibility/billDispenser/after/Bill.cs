﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chain_of_responsibility.billDispenser.after
{
    internal class Bill
    {
        private int value;
        private Bill next;

        public Bill(int value)
        {
            this.value = value;
        }

        public Bill(int value, Bill next)
        {
            this.value = value;
            this.next = next;
        }

        public void SetNext(Bill bill)
        {
            this.next = bill;
        }

        public void Execute(int remaining)
        {
            if (remaining >= value)
            {
                int bills = remaining / value;
                remaining %= value;
                Console.WriteLine(string.Format("- {0} bill(s) of {1}, {2} remaining", bills, value, remaining));
            }
            if (remaining == 0) return;
            if (next != null) next.Execute(remaining);
        }
    }
}
