﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chain_of_responsibility.billDispenser.after
{
    internal class Dispenser
    {
        private Bill chain;

        public Dispenser()
        {
            this.chain = new Bill(200,
                new Bill(100,
                    new Bill(50,
                        new Bill(20,
                            new Bill(10,
                                new Bill(5,
                                    new Bill(2)))))));
        }

        public Dispenser(params Bill[] bills)
        {
            for (int index = 0; index < bills.Length - 1; index++)
            {
                Bill currentBill = bills[index];
                currentBill.SetNext(bills[index + 1]);
            }
            chain = bills[0];
        }

        public void WithDraw(int amount)
        {
            chain.Execute(amount);
        }
    }
}
