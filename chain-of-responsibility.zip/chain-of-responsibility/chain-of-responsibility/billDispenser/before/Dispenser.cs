﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chain_of_responsibility.billDispenser.before
{
    internal class Dispenser
    {
        public void Withdraw(int amount)
        {
            int remaining = amount;
            Console.WriteLine("Calculating bills set for $" + amount);
            if (remaining >= 200)
            {
                int bills = remaining / 200;
                remaining %= 200;
                Console.WriteLine(string.Format("- {0} bill(s) of 200, {1} remaining", bills, remaining));
            }
            if (remaining >= 100)
            {
                int bills = remaining / 100;
                remaining %= 100;
                Console.WriteLine(string.Format("- {0} bill(s) of 100, {1} remaining", bills, remaining));
            }
            if (remaining >= 50)
            {
                int bills = remaining / 50;
                remaining %= 50;
                Console.WriteLine(string.Format("- {0} bill(s) of 50, {1} remaining", bills, remaining));
            }
            if (remaining >= 20)
            {
                int bills = remaining / 20;
                remaining %= 20;
                Console.WriteLine(string.Format("- {0} bill(s) of 20, {1} remaining", bills, remaining));
            }
            if (remaining >= 10)
            {
                int bills = remaining / 10;
                remaining %= 10;
                Console.WriteLine(string.Format("- {0} bill(s) of 10, {1} remaining", bills, remaining));
            }
            if (remaining >= 2)
            {
                int bills = remaining / 2;
                remaining %= 2;
                Console.WriteLine(string.Format("- {0} bill(s) of 2, {1} remaining", bills, remaining));
            }
        }
    }
}
