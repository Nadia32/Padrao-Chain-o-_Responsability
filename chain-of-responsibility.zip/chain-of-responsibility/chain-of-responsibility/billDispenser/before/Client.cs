﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chain_of_responsibility.billDispenser.before
{
    internal class Client
    {
        public static void Main(string[] args)
        {
            Dispenser atm = new Dispenser();
            atm.Withdraw(230);
            Console.WriteLine("------------------");
            atm.Withdraw(66);
            Console.WriteLine("------------------");
            atm.Withdraw(1796);

            Console.ReadKey();
        }
    }
}
